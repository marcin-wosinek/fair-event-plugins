# fair-timetable

## 0.2.0

### Minor Changes

- 0dc7363: Initial version of the plugin

## 0.1.0

Initial version of the plugin.
