/**
 * Schedule Column Block
 *
 * Block for organizing time blocks in columns by track, day, or category.
 */
// Import styles
import './style.css';
