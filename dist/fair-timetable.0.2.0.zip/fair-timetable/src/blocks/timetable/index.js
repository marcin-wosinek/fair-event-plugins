/**
 * Timetable block registration
 */
import './style.css';
