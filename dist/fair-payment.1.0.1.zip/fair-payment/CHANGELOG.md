# fair-payment

## 1.0.1

### Patch Changes

- Update dependencies to the newest version
